const exchangeType = {
  XNAS: 'NASDAQ',
  XNYS: 'NYSE',
  // Add other exchanges as needed
};

export default exchangeType;
