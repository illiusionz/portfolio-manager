// src/containers/AssetManagement/AssetManagement.js
import React from 'react';
import AssetManagementCalculator from '../../components/AssetManagementCalculator/AssetManagementCalculator';

const AssetManagement = () => {
  return (
    <div className='container-fluid'>
      <div className='hero-section'>
        <h1>Asset Management</h1>
      </div>
      <AssetManagementCalculator />
    </div>
  );
};

export default AssetManagement;
