const plaidClient = require('../services/plaid/plaidClient');

// Create a link token for Plaid Link
exports.createLinkToken = async (req, res) => {
  try {
    console.log('Creating link token for user...');
    const response = await plaidClient.createLinkToken('user-id'); // Call function from plaidClient
    console.log('Link token created:', response);
    res.json(response);
  } catch (error) {
    console.error('Error creating link token:', error);
    res.status(500).json({ error: error.message });
  }
};

// Exchange public token for access token
exports.exchangePublicToken = async (req, res) => {
  const { public_token } = req.body;
  try {
    const response = await plaidClient.exchangePublicToken(public_token); // Call function from plaidClient
    res.json({ access_token: response.access_token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller to get transactions
exports.getTransactions = async (req, res) => {
  const { access_token } = req.body;

  try {
    const response = await plaidClient.transactionsGet({
      access_token: access_token,
      start_date: '2020-01-01', // Example dates, adjust as needed
      end_date: '2024-01-01',
    });

    const transactions = response.data.transactions;
    res.status(200).json({ transactions });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Unable to fetch transactions' });
  }
};
