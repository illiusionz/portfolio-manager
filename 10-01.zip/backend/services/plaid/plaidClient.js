const path = require('path');
const { Configuration, PlaidApi, PlaidEnvironments } = require('plaid');
require('dotenv').config({ path: path.resolve(__dirname, '../../../.env') }); // Adjust path to project root

// Log environment variables
console.log('PLAID_CLIENT_ID:', process.env.PLAID_CLIENT_ID);
console.log('PLAID_SECRET:', process.env.PLAID_SECRET);
console.log('PLAID_ENV:', process.env.PLAID_ENV);

// Initialize the Plaid client using PlaidApi
const config = new Configuration({
  basePath: PlaidEnvironments[process.env.PLAID_ENV],
  baseOptions: {
    headers: {
      'PLAID-CLIENT-ID': process.env.PLAID_CLIENT_ID,
      'PLAID-SECRET': process.env.PLAID_SECRET,
    },
  },
});

const client = new PlaidApi(config);

/**
 * Function to create a link token for the Plaid Link UI
 */
const createLinkToken = async (userID) => {
  try {
    const response = await client.linkTokenCreate({
      user: {
        client_user_id: userID, // Unique user ID
      },
      client_name: 'Your App Name',
      products: ['transactions'], // List of Plaid products to access
      country_codes: ['US'], // Specify country
      language: 'en', // Language of the Plaid Link UI
    });
    return response.data; // With the new SDK, use response.data
  } catch (error) {
    throw new Error(`Error creating link token: ${error.message}`);
  }
};

/**
 * Function to exchange a public token for an access token
 */
const exchangePublicToken = async (publicToken) => {
  try {
    const response = await client.itemPublicTokenExchange({
      public_token: publicToken,
    });
    return response.data;
  } catch (error) {
    throw new Error(`Error exchanging public token: ${error.message}`);
  }
};

/**
 * Function to fetch transactions using the access token
 */
const getTransactions = async (accessToken, startDate, endDate) => {
  try {
    const response = await client.transactionsGet({
      access_token: accessToken,
      start_date: startDate,
      end_date: endDate,
    });
    return response.data.transactions;
  } catch (error) {
    throw new Error(`Error fetching transactions: ${error.message}`);
  }
};

module.exports = {
  createLinkToken,
  exchangePublicToken,
  getTransactions,
};
