export const selectUserSymbol = (state) => state.user.userSymbol;
