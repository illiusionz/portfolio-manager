// bankSlice.js
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

// Async thunk to fetch transactions
export const fetchTransactions = createAsyncThunk(
  'bank/fetchTransactions',
  async (access_token, { rejectWithValue }) => {
    try {
      const response = await fetch('/api/plaid/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ access_token }),
      });
      const data = await response.json();
      return data.transactions; // Plaid returns transactions in this key
    } catch (err) {
      return rejectWithValue(err.response.data);
    }
  }
);

const bankSlice = createSlice({
  name: 'bank',
  initialState: {
    transactions: [],
    status: 'idle',
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchTransactions.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchTransactions.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.transactions = action.payload;
      })
      .addCase(fetchTransactions.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  },
});

export default bankSlice.reducer;
