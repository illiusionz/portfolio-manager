import { useEffect, useState } from 'react';
import { usePlaidLink } from 'react-plaid-link';
import { useDispatch } from 'react-redux';
import { fetchTransactions } from '../../features/bank/bankSlice';
import { usePlaidLinkHook } from '../../hooks/usePlaidLink';


const PlaidLinkComponent = () => {
  const [linkToken, setLinkToken] = useState(null);
  const dispatch = useDispatch();

  useEffect(() => {
    const fetchLinkToken = async () => {
      const response = await fetch('/api/plaid/create_link_token', { method: 'POST' });
      const data = await response.json();
      setLinkToken(data.link_token);
    };

    fetchLinkToken();
  }, []);

  const { open, ready } = usePlaidLink({
    token: linkToken,
    onSuccess: async (public_token) => {
      const res = await fetch('/api/plaid/exchange_public_token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ public_token }),
      });
      const { access_token } = await res.json();
      dispatch(fetchTransactions(access_token));
    },
  });

  return (
    <button onClick={() => open()} disabled={!ready}>
      Connect Bank Account
    </button>
  );
};

export default PlaidLinkComponent;
