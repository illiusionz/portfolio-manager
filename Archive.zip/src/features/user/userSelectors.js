// src/features/user/userSelectors.js
export const selectUserSymbol = (state) => state.user.symbol;
export const selectStockPrice = (state) => state.user.stockPrice;
