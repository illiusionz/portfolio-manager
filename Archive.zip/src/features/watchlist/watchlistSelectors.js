// src/features/watchlist/watchlistSelectors.js
export const selectWatchlistSymbols = (state) => state.watchlist.symbols;
export const selectWatchlistData = (state) => state.watchlist.data;
