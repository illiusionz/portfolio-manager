// src/redux/actions/userActions.js
export const setUserSymbol = (symbol) => ({
  type: 'SET_USER_SYMBOL',
  payload: symbol,
});
