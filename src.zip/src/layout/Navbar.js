import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import Autosuggest from 'react-autosuggest';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars } from '@fortawesome/free-solid-svg-icons';
import './Navbar.css';
import flagIcons from '../utils/flagIcons';
import exchangeType from '../utils/exchanges';
import { fetchStockPrice } from '../redux/actions/stockActions';
import { setUserSymbol } from '../redux/actions/userActions';

const Navbar = ({ toggleSidebar }) => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dispatch = useDispatch();

  const fetchBrandingAndLocale = async (ticker) => {
    try {
      const response = await fetch(
        `https://api.polygon.io/v3/reference/tickers/${ticker}?apiKey=6kf3MOEaHc3lbVrjKbqgjqcOo7pgMZmq`
      );
      const data = await response.json();
      return data.results || {};
    } catch (error) {
      console.error('Error fetching branding and locale:', error);
      return {};
    }
  };

  const onSuggestionsFetchRequested = async ({ value }) => {
    try {
      const response = await fetch(
        `https://api.polygon.io/v3/reference/tickers?search=${value}&active=true&sort=ticker&order=asc&limit=10&apiKey=6kf3MOEaHc3lbVrjKbqgjqcOo7pgMZmq`
      );
      const data = await response.json();
      const results = data.results || [];

      const suggestionsWithBranding = await Promise.all(
        results.map(async (suggestion) => {
          const brandingData = await fetchBrandingAndLocale(suggestion.ticker);
          return {
            ...suggestion,
            branding: brandingData.branding,
            locale: brandingData.locale,
          };
        })
      );

      setSuggestions(suggestionsWithBranding);
    } catch (error) {
      console.error('Error fetching suggestions:', error);
      setSuggestions([]);
    }
  };

  const onSuggestionsClearRequested = () => {
    setSuggestions([]);
  };

  const getSuggestionValue = (suggestion) =>
    `${suggestion.ticker} - ${suggestion.name}`;

  const renderSuggestion = (suggestion) => (
    <div className='suggestion-item'>
      <span className='suggestion-ticker'>{suggestion.ticker}</span>
      <span className='suggestion-name'>{suggestion.name}</span>
      <span className='suggestion-exchange'>
        {exchangeType[suggestion.primary_exchange]}
        <img
          src={flagIcons[suggestion.locale] || 'default-flag-url'}
          alt={suggestion.locale}
          className='flag-icon'
        />
      </span>
    </div>
  );

  const onChange = (event, { newValue }) => {
    setQuery(newValue);
  };

  const onSuggestionSelected = (event, { suggestion }) => {
    dispatch(setUserSymbol(suggestion.ticker));
    dispatch(fetchStockPrice(suggestion.ticker));
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const symbol = query.split(' - ')[0];
    dispatch(setUserSymbol(symbol));
    dispatch(fetchStockPrice(symbol));
  };

  const inputProps = {
    placeholder: 'Search for a stock',
    value: query,
    onChange: onChange,
  };

  const toggleDropdown = () => {
    setDropdownVisible(!dropdownVisible);
  };

  return (
    <nav className='navbar navbar-expand-lg navbar-light bg-light'>
      <button className='btn btn-primary' onClick={toggleSidebar}>
        <FontAwesomeIcon icon={faBars} />
      </button>
      <form className='form-inline my-2 my-lg-0' onSubmit={onSubmit}>
        <Autosuggest
          suggestions={suggestions}
          onSuggestionsFetchRequested={onSuggestionsFetchRequested}
          onSuggestionsClearRequested={onSuggestionsClearRequested}
          getSuggestionValue={getSuggestionValue}
          renderSuggestion={renderSuggestion}
          inputProps={inputProps}
          onSuggestionSelected={onSuggestionSelected}
        />
        <button className='btn btn-outline-success my-2 my-sm-0' type='submit'>
          Search
        </button>
      </form>
      <ul className='navbar-nav navbar-align'>
        <li className='nav-item dropdown'>
          <div
            className='nav-link dropdown-toggle'
            onClick={toggleDropdown}
            aria-expanded={dropdownVisible}>
            <img
              src='../assets/images/user-image.jpg'
              alt='User'
              className='user-image'
            />
            <span className='user-name'>Jeff Liu</span>
          </div>
          <div
            className={`dropdown-menu dropdown-menu-end ${
              dropdownVisible ? 'show' : ''
            }`}>
            <a className='dropdown-item' href='/profile'>
              Profile
            </a>
            <a className='dropdown-item' href='/analytics'>
              Analytics
            </a>
            <div className='dropdown-divider'></div>
            <a className='dropdown-item' href='/settings'>
              Settings &amp; Privacy
            </a>
            <a className='dropdown-item' href='/help'>
              Help
            </a>
            <a className='dropdown-item' href='/signout'>
              Sign out
            </a>
          </div>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
