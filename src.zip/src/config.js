// src/config.js
const config = {
  polygonApiKey: '6kf3MOEaHc3lbVrjKbqgjqcOo7pgMZmq',
};

export default config;
