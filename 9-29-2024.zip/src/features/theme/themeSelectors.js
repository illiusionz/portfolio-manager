// src/features/theme/themeSelectors.js
export const selectTheme = (state) => state.theme;
