// watchlistThunks.js
import { createAsyncThunk } from '@reduxjs/toolkit';
import { setWatchlistData } from './watchlistSlice';
import axios from 'axios';

const apiKey = process.env.REACT_APP_POLYGON_API_KEY;

export const fetchWatchlistData = createAsyncThunk(
  'watchlist/fetchWatchlistData',
  async (symbols, { dispatch, rejectWithValue }) => {
    try {
      // Fetch data for all symbols in watchlist
      const responses = await Promise.all(
        symbols.map((symbol) =>
          axios.get(
            `https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}?apiKey=${apiKey}`
          )
        )
      );

      // Format the response data
      const data = responses.reduce((acc, response) => {
        const { ticker } = response.data;
        acc[ticker.ticker] = ticker;
        return acc;
      }, {});

      // Update the watchlist data in the store
      dispatch(setWatchlistData(data));

      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);
