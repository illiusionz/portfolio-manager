// watchlistSlice.js
import { createSlice } from '@reduxjs/toolkit';
import { fetchWatchlistData } from './watchlistThunks';

const initialState = {
  symbols: [], // Symbols in the watchlist
  data: {}, // Data for each symbol
  loading: false,
  error: null,
};

const watchlistSlice = createSlice({
  name: 'watchlist',
  initialState,
  reducers: {
    setWatchlistSymbols(state, action) {
      state.symbols = action.payload;
    },
    addToWatchlist(state, action) {
      if (!state.symbols.includes(action.payload)) {
        state.symbols.push(action.payload);
      }
    },
    removeFromWatchlist(state, action) {
      state.symbols = state.symbols.filter(
        (symbol) => symbol !== action.payload
      );
      delete state.data[action.payload];
    },
    setWatchlistData(state, action) {
      state.data = { ...state.data, ...action.payload };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchWatchlistData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchWatchlistData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(fetchWatchlistData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const {
  setWatchlistSymbols,
  addToWatchlist,
  removeFromWatchlist,
  setWatchlistData,
} = watchlistSlice.actions;

export default watchlistSlice.reducer;
