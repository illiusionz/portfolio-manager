// src/features/stocks/stockSelectors.js
import { createSelector } from '@reduxjs/toolkit';

// Base selector to access the stock state
export const selectStockState = (state) => state.stocks;

// Selector to get the stock snapshot data
export const selectStockSnapshot = createSelector(
  selectStockState,
  (stocks) => stocks.stockSnapshot
);

// Selector to get specific stock field
export const selectStockField = createSelector(
  [selectStockSnapshot, (_, field) => field],
  (stockData, field) => (stockData ? stockData[field] : null)
);

// Selector to get stock price from prevDay's close ('c')
export const selectStockPrice = createSelector(
  selectStockSnapshot,
  (snapshot) => snapshot?.prevDay?.c || null
);

// Selector to get stock error
export const selectStockError = createSelector(
  selectStockState,
  (stocks) => stocks.error
);

// Selector to get detailed stock information
export const selectStockDetails = (state, symbol) =>
  state.stocks.stockDetails[symbol] || {};
