const flagIcons = {
  us: 'https://cdn.jsdelivr.net/gh/lipis/flag-icons/flags/4x3/us.svg',
  ca: 'https://cdn.jsdelivr.net/gh/lipis/flag-icons/flags/4x3/ca.svg',
  // Add other countries as needed
};

export default flagIcons;
