import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const apiKey = '6kf3MOEaHc3lbVrjKbqgjqcOo7pgMZmq';

// Fetch historical stock data
export const fetchStocks = createAsyncThunk(
  'stocks/fetchStocks',
  async (symbol, { rejectWithValue }) => {
    console.log(`Fetching historical stock data for symbol: ${symbol}`);
    const url = `https://api.polygon.io/v2/aggs/ticker/${symbol}/range/1/day/2023-01-01/2023-12-31?apiKey=${apiKey}`;

    try {
      const response = await axios.get(url);
      console.log('Historical stock data:', response.data);
      return response.data.results;
    } catch (error) {
      console.error('Error fetching historical stock data:', error);
      return rejectWithValue('Failed to fetch historical stock data');
    }
  }
);

// Fetch real-time stock price
export const fetchStockPrice = createAsyncThunk(
  'stocks/fetchStockPrice',
  async (symbol, { rejectWithValue }) => {
    console.log(`Fetching real-time stock price for symbol: ${symbol}`);
    const url = `https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}?apiKey=${apiKey}`;

    try {
      const response = await axios.get(url);
      console.log('Real-time stock price data:', response.data);
      return response.data.ticker.day.o; // Assuming 'day.o' is the opening price you want
    } catch (error) {
      console.error('Error fetching real-time stock price:', error);
      if (error.response && error.response.status === 403) {
        return rejectWithValue(
          'Access forbidden: check API key and permissions.'
        );
      } else {
        return rejectWithValue('Error fetching real-time stock price');
      }
    }
  }
);
